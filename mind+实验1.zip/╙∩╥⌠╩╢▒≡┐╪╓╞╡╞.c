/*!
 * MindPlus
 * mpython
 *
 */
#include <MPython.h>
#include <DFRobot_Iot.h>
#include <MPython_ASR.h>
// ��������
DFRobot_Iot myIot;
MPython_ASR mpythonAsr;
String      str_mpythonAsr_result;


// ������ʼ
void setup() {
	mPython.begin();
	myIot.wifiConnect("666", "11111111");
	display.setCursorLine(1);
	display.printLine("�������Ӵ��ȵ�...IPΪ��");
	while (!myIot.wifiStatus()) {yield();}
	display.setCursorLine(2);
	display.printLine(myIot.getWiFiLocalIP());
	display.setCursorLine(3);
	display.printLine("��A��ʶ��");
}
void loop() {
	if ((buttonA.isPressed())) {
		str_mpythonAsr_result=mpythonAsr.getAsrResult(1);
		display.setCursorLine(4);
		display.printLine((str_mpythonAsr_result));
	}
	else if (((String(str_mpythonAsr_result).indexOf(String("����")) != -1))) {
		rgb.write(1, 0xFFFF00);
		rgb.brightness(round(3));
	}
	else if (((String(str_mpythonAsr_result).indexOf(String("�ص�")) != -1))) {
		rgb.write(1, 0x000000);
	}
}
