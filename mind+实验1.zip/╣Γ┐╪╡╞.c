/*!
 * MindPlus
 * mpython
 *
 */
#include <MPython.h>


// ������ʼ
void setup() {
	mPython.begin();
	display.setCursorLine(1);
	display.printLine("����ǿ��");
}
void loop() {
	display.setCursorLine(2);
	display.printLine((light.read()));
	if (((light.read())<100)) {
		rgb.write(-1, 0x0000FF);
		delay(1000);
	}
	else {
		rgb.write(-1, 0x000000);
	}
}

